"""
MEDUSA Configuration Templates
Template files for IDE configurations, shell wrappers, and agent configs
"""

__all__ = []
